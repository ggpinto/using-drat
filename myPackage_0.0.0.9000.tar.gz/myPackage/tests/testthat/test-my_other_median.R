test_that("my_median works properly and show error if needed", {
  expect_true(my_other_median(1:12) == 6.5)
  expect_error(my_other_median("text"))
})
